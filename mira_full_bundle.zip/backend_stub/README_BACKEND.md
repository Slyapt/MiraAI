Backend stub (optional). For full online features, implement a backend with endpoints:
- POST /chat { message, persona, emotion, profanityMode } -> { ok:true, text: '...' }
- OAuth endpoints for Gmail and Twilio integration
- Storage for user tokens (encrypted) and optional cloud-sync for memory

You can reuse the earlier jarvis backend code and adapt to /chat endpoint.

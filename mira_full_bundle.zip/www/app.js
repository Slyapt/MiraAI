/*
Mira web frontend logic (Offline-first). Hotword wake is simulated in browser via button.
In Android native build, a foreground service will implement real hotword detection and will trigger the WebView via JS bridge.
*/
const conv = document.getElementById('conversation');
const input = document.getElementById('input');
const send = document.getElementById('send');
const wakeTest = document.getElementById('wakeTest');
const status = document.getElementById('status');
const sailorModeCheckbox = document.getElementById('sailorMode');
const hotwordCheckbox = document.getElementById('hotword');

let memory = JSON.parse(localStorage.getItem('mira_memory')||'{}');
let memSpan = localStorage.getItem('mira_mem_span')||'forever';
let ONLINE_API = ''; // set to backend URL for online mode
let online = false;

// Simple functions
function append(who, text){ const d = document.createElement('div'); d.innerText = (who==='you'?'You: ':'Mira: ')+text; conv.appendChild(d); conv.scrollTop = conv.scrollHeight; }
function thinkSound(){ // play short thinking sound variation
  const s = new Audio('assets/thinking1.mp3'); s.play();
}

// local lightweight emotion engine + reply generator
function localReply(text){
  const emo = document.getElementById('emotion').value;
  const profanity = document.getElementById('profanity').value;
  const sailor = sailorModeCheckbox.checked;
  let base = '';
  if(/\b(why|how|what|explain)\b/i.test(text)) base = 'Here is a quick local answer: ' + text;
  else base = ['Hmm','Alright','Nice','Got it'][Math.floor(Math.random()*4)] + ' — ' + text;
  if(emo==='sarcastic') base = 'Oh sure. ' + base + ' 😉';
  if(emo==='sassy') base = 'Listen, ' + base;
  if(sailor && /fuck|shit|damn|bitch/ig.test(text)) base = base + ' — and seriously, watch your mouth.';
  if(profanity==='censor') base = base.replace(/fuck|shit|damn|bitch/ig, (m)=>'*'.repeat(m.length));
  return base;
}

// memory helpers
function saveMemory(){ localStorage.setItem('mira_memory', JSON.stringify(memory)); }
function addMemory(key,val){ memory[key]=val; saveMemory(); }

send.addEventListener('click', async ()=>{
  const t = input.value.trim(); if(!t) return;
  append('you', t); input.value='';
  // if online and backend configured, call online API
  if(ONLINE_API){ status.innerText='Online'; try{
    const r = await fetch(ONLINE_API+'/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:t,persona:'mira',emotion:document.getElementById('emotion').value,profanityMode:document.getElementById('profanity').value})});
    const j = await r.json(); if(j.ok){ append('mira', j.text); speech(j.text); } else { append('mira','[error] '+j.error); }
  }catch(e){ append('mira','[network error] Using local fallback.'); append('mira', localReply(t)); speech(localReply(t)); status.innerText='Offline'; }
  } else {
    append('mira', localReply(t)); speech(localReply(t));
  }
});

wakeTest.addEventListener('click', ()=>{ // simulate being woken by 'Hey Mira'
  append('mira','(wakes) Yeah? You called?');
  thinkSound();
  // bring attention
  setTimeout(()=> append('mira','What can I do for you?'),800);
});

// simple speech synthesis
function speech(text){
  if(!('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1.0; // vary with emotion
  window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
}

// local reminder demo
document.getElementById('remind').addEventListener('click', ()=>{
  const mins = parseInt(prompt('Remind after how many minutes?'),10); if(!mins) return;
  const note = prompt('Reminder text:')||'Reminder';
  append('mira','Reminder set: '+note+' in '+mins+' minutes.');
  setTimeout(()=>{ append('mira','🔔 Reminder: '+note); speech('Reminder: '+note); }, mins*60000);
});

// storage & init
(function init(){ if(!localStorage.getItem('mira_memory')) saveMemory(); document.getElementById('memSpan').value = memSpan; })();

Mira Full Bundle — Ready-to-build scaffold (Hotword + Sailor Mode + Memory)

What's included:
- www/ : interactive web frontend (offline-first), voice/emotion controls, memory hooks, thinking sounds, sailor mode toggle.
- android_stub/: Kotlin foreground service stub + hotword integration notes (Porcupine recommended).
- electron/: electron wrapper for desktop builds (macOS & Windows).
- codemagic.yaml : pipeline to build Android APK in Codemagic (cloud).
- assets/: Mira logo SVG/PNG and thinking sound placeholders.
- backend_stub/: notes for backend endpoints for full online features.

Important: Hotword & background listening
- Android: Implement HotwordService (foreground service) and integrate Porcupine for on-device wake-word detection. Requires RECORD_AUDIO permission and user enabling battery optimization exemption for persistent listening.
- iOS: Background hotword detection is restricted. You can use background audio sessions + voice activation but performance and App Store acceptance may be affected. Alternative: use push-to-talk or Siri Shortcuts integration.

Sailor Mode (unfiltered cussing)
- App supports selectable profanity levels: censor / normal / explicit.
- Sailor Mode toggles unfiltered responses. Use responsibly and be aware of local laws and app store policies when publishing.

Memory & privacy
- By default, memory is stored locally encrypted in device storage. You can enable optional cloud-sync by implementing a secure backend and encrypting data at rest (AES-256).
- Users must be able to clear memory fully (settings -> clear memory).

How to build (quick):
1) Upload this bundle to Codemagic (https://codemagic.io) and configure environment variables & signing keys (SIGNING_KEY_BASE64 etc.)
2) Codemagic will run the pipeline and output APK artifacts for download.
3) For iOS, use Codemagic or Xcode on macOS to build an IPA (Apple Developer account required).
4) For desktop, run `npm install` in /electron and `npm start`, then package via electron-builder.

Security & legal notes:
- Background microphone access must be explicit and clearly explained to the user. Provide a settings screen explaining why Mira listens in background.
- App stores may have rules regarding always-on listening; consult App Store and Play Store guidelines before distribution.

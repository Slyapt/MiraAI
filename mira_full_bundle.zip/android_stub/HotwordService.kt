/*
Kotlin ForegroundService stub (android/). This is a template to implement a hotword detector (Porcupine or Snowboy).
Place inside android/app/src/main/java/com/mira/service/HotwordService.kt
*/
package com.mira.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat

class HotwordService: Service() {
    override fun onBind(intent: Intent?): IBinder? { return null }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Mira is listening")
            .setContentText("Say 'Hey Mira' to wake me")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, notification)

        // TODO: Initialize Porcupine / Snowboy hotword engine here and listen on microphone
        // On detection, use a JS bridge to call the WebView: webView.post(() -> webView.evaluateJavascript("window.onMiraWake()", null));
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Mira Hotword", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object { const val CHANNEL_ID = "mira_hotword_channel" }
}

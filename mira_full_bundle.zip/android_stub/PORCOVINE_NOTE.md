Porcupine Hotword Integration (recommended):
- Porcupine (Picovoice) offers on-device wake-word detection with low CPU & privacy-friendly.
- Steps:
  1. Create an account at Picovoice/Porcupine and request custom keyword for 'hey mira' or use built-in generic keywords.
  2. Add Porcupine Android SDK to your project (Maven dependency) and follow examples to initialize with model and keyword file.
  3. On detection, signal the WebView via JS bridge (evaluateJavascript) to wake Mira's UI and play thinking sound.
- Alternative: Snowboy custom models (no longer maintained) or Vosk-based models for offline speech recognition.

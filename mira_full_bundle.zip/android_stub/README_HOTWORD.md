Add to AndroidManifest.xml (android/app/src/main/AndroidManifest.xml):

<service android:name="com.mira.service.HotwordService" android:foregroundServiceType="microphone" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.WAKE_LOCK" />

Notes:
- Request RECORD_AUDIO at runtime.
- To run when device is locked, start HotwordService as a foreground service and request battery-exemption (user action).
- Porcupine provides lightweight on-device hotword models; integrate per their docs.
